#include "pch.h"
#include "Graph.h"
#include <queue>
#include <iostream>
#include <iomanip> 

// SalesmanTrackProbabilistic ==================================================

CTrack SalesmanTrackProbabilistic(CGraph& graph, CVisits& visits)
{
	return CTrack(&graph);
}
