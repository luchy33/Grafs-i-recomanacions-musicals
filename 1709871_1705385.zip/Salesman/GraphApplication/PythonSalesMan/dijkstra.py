import graph
import math
import sys
import queue

# Dijkstra =====================================================================

def Dijkstra(g, start):
    pendents = set()
    for node in g.Vertices:
        if node == start:
            node.DijkstraDistance = 0.0
        else:
            node.DijkstraDistance = sys.float_info.max
        pendents.add(node)

    while pendents:
        for aresta in start.Edges:
            desti = aresta.Destination
            nova_dist = start.DijkstraDistance + aresta.Length
            if desti in pendents and nova_dist < desti.DijkstraDistance:
                desti.DijkstraDistance = nova_dist

        pendents.remove(start)

        millor_dist = sys.float_info.max
        seguent = None

        for node in pendents:
            if node.DijkstraDistance <= millor_dist:
                millor_dist = node.DijkstraDistance
                seguent = node

        if millor_dist == sys.float_info.max:
            break

        start = seguent

# DijkstraQueue ================================================================

def DijkstraQueue(g, start):
    visitats = {}
    predecessors = {}

    cua = queue.PriorityQueue()
    for node in g.Vertices:
        if node == start:
            node.DijkstraDistance = 0
        else:
            node.DijkstraDistance = sys.float_info.max
        visitats[node] = False
        predecessors[node] = None

    cua.put([start.DijkstraDistance, start])
    while not cua.empty():
        node_tractat = cua.get()
        if not visitats[node_tractat[1]]:
            for aresta in node_tractat[1].Edges:
                distancia_actual = aresta.Destination.DijkstraDistance
                nova_dist = node_tractat[0] + aresta.Length
                if nova_dist < distancia_actual:
                    aresta.Destination.DijkstraDistance = nova_dist
                    cua.put([aresta.Destination.DijkstraDistance, aresta.Destination])
                    predecessors[aresta.Destination] = node_tractat[1]
            visitats[node_tractat[1]] = True
    return predecessors


