
import graph
import math
import sys
import queue
import dijkstra

# SalesmanTrackGreedy ==========================================================

def SalesmanTrackGreedy(g, visits):
    actual = visits.Vertices[0]
    possibles = visits.Vertices[1:-1]

    track = graph.Track(g)
    
    while possibles:
        llista_arestes = []
        camins = dijkstra.DijkstraQueue(g, actual)
        
        minim = sys.float_info.max
        node_minim = None
        for node in possibles:
            if node.DijkstraDistance < minim:
                node_minim, minim = node, node.DijkstraDistance

        desti = node_minim
        while node_minim is not actual:
            vei = camins[node_minim]
            if node_minim in possibles:
                possibles.remove(node_minim)
            for aresta in vei.Edges: 
                if aresta.Destination is node_minim:
                    llista_arestes.append(aresta)
                    break
            node_minim = vei
        actual = desti
        [track.AddLast(aresta) for aresta in llista_arestes[::-1]]

    llista_arestes = []
    camins = dijkstra.DijkstraQueue(g, actual)

    desti_final = visits.Vertices[-1]
    while desti_final is not actual:
        vei = camins[desti_final]
        for aresta in vei.Edges: 
            if aresta.Destination is desti_final:
                llista_arestes.append(aresta)
                break
        desti_final = vei
    [track.AddLast(aresta) for aresta in llista_arestes[::-1]]

    return track
