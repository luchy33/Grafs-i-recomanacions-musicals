import graph
import math
import sys
import queue
import dijkstra
   
# SalesmanTrackBranchAndBound1 ===================================================

def SalesmanTrackBranchAndBound1(g, visits):
    return graph.Track(g)


# SalesmanTrackBranchAndBound2 ===================================================

def SalesmanTrackBranchAndBound2(g, visits):
    return graph.Track(g)

# SalesmanTrackBranchAndBound3 ===================================================

def SalesmanTrackBranchAndBound3(g, visits):
    return graph.Track(g)
	