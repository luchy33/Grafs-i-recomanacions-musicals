import graph
import math
import sys
import queue
from dijkstra import DijkstraQueue
from greedy import SalesmanTrackGreedy 

def SalesmanTrackBacktracking(g, visits):
    camiFinal = graph.Track(g)
    camiActual = graph.Track(g)
    distanciaFinal = sys.float_info.max
    arestesVisitades = set()
    compFi = len(visits.Vertices)

    for vertex in g.Vertices:
        vertex.visitada = vertex in visits.Vertices
        vertex.estaVisitat = 0

    origen = visits.Vertices[0]
    origen.estaVisitat = 1

    def backtracking(vertexActual, distanciaActual, camiActual, comp):
        nonlocal distanciaFinal, camiFinal

        if distanciaActual >= distanciaFinal:
            return

        if comp == compFi and vertexActual is visits.Vertices[-1]:
            if distanciaActual < distanciaFinal:
                distanciaFinal = distanciaActual
                camiFinal.Edges[:] = camiActual.Edges[:]
            return

        for aresta in vertexActual.Edges:
            if aresta not in arestesVisitades:
                vei = aresta.Destination

                eraVisitat = vei.estaVisitat
                compNou = comp

                if vei.visitada and eraVisitat == 0:
                    vei.estaVisitat = 1
                    compNou += 1

                arestesVisitades.add(aresta)
                camiActual.AddLast(aresta)

                backtracking(vei, distanciaActual + aresta.Length, camiActual, compNou)

                camiActual.Edges.pop()
                arestesVisitades.remove(aresta)
                if vei.visitada and eraVisitat == 0:
                    vei.estaVisitat = 0

    backtracking(origen, 0, camiActual, 1)
    return camiFinal

# ==============================================================================


def SalesmanTrackBacktrackingGreedy(graf, visites):
    def reconstruir_cami_dijkstra(origen, desti, predecessors):
        cami_final = []
        node_actual = desti
        while node_actual != origen:
            node_precedent = predecessors.get(node_actual)
            if node_precedent is None:
                return []
            for enllaç in node_precedent.Edges:
                if enllaç.Destination == node_actual:
                    cami_final.append(enllaç)
                    break
            node_actual = node_precedent
        cami_final.reverse()
        return cami_final

    total_visites = len(visites.Vertices)

    if total_visites == 2:
        predecessors = DijkstraQueue(graf, visites.Vertices[0])
        cami_ideal = reconstruir_cami_dijkstra(visites.Vertices[0], visites.Vertices[1], predecessors)

        ruta = graph.Track(graf)
        for enllaç in cami_ideal:
            ruta.AddLast(enllaç)
        return ruta

    millor_distancia = [math.inf]
    millor_ruta = [[]]

    distancies = [[math.inf] * total_visites for _ in range(total_visites)]
    camins = [[[] for _ in range(total_visites)] for _ in range(total_visites)]

    for i, node_origen in enumerate(visites.Vertices):
        predecessors = DijkstraQueue(graf, node_origen)
        for j, node_desti in enumerate(visites.Vertices):
            if i != j:
                cami = reconstruir_cami_dijkstra(node_origen, node_desti, predecessors)
                if cami:
                    distancies[i][j] = sum(enllaç.Length for enllaç in cami)
                    camins[i][j] = cami

    nodes_visitats = [False] * total_visites
    nodes_visitats[0] = True
    cami_actual = []
    distancia_actual = [0]

    def backtrack(indicador_node, profunditat):
        if profunditat == total_visites - 1:
            if distancies[indicador_node][total_visites - 1] == math.inf:
                return
            distancia_total = distancia_actual[0] + distancies[indicador_node][total_visites - 1]
            if distancia_total < millor_distancia[0]:
                millor_distancia[0] = distancia_total
                millor_ruta[0] = cami_actual + camins[indicador_node][total_visites - 1]
            return

        for node_seguent in range(1, total_visites - 1):
            if not nodes_visitats[node_seguent] and distancies[indicador_node][node_seguent] != math.inf:
                nova_distancia = distancia_actual[0] + distancies[indicador_node][node_seguent]
                if nova_distancia >= millor_distancia[0]:
                    continue
                nodes_visitats[node_seguent] = True
                cami_actual.extend(camins[indicador_node][node_seguent])
                distancia_actual[0] = nova_distancia

                backtrack(node_seguent, profunditat + 1)

                for _ in camins[indicador_node][node_seguent]:
                    cami_actual.pop()
                distancia_actual[0] -= distancies[indicador_node][node_seguent]
                nodes_visitats[node_seguent] = False

    backtrack(0, 1)

    ruta_resultant = graph.Track(graf)
    for enllaç in millor_ruta[0]:
        ruta_resultant.AddLast(enllaç)
    return ruta_resultant
